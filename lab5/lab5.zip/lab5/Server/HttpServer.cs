﻿using Server.Sorting;
using System;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Server
{
    public class HttpServer
    {
        private readonly Regex _requestTitleRegex = new(@"(?<httpMethod>\S+)\s+(?<httpPath>\S+)\s+(?<httpVersion>\S+)", RegexOptions.Compiled);
        private const int BufferSize = 2048;

        private int _port;

        public HttpServer(int port = 8080)
        {
            _port = port;
        }

        public void Start()
        {
            var listener = new TcpListener(IPAddress.Any, _port);
            listener.Start();
            while (true)
            {
                Console.WriteLine($"Server started listening on {listener.LocalEndpoint}");

                var client = listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(
                state =>
                {
                    ProcessClient(state as TcpClient);
                }, client);
            }
        }

        private void ProcessClient(TcpClient client)
        {
            var stream = client.GetStream();
            try
            {
                stream.ReadTimeout = 10000;
                stream.WriteTimeout = 10000;

                var requestMessage = ReadMessage(stream);
                Console.WriteLine($"Received request: {requestMessage}");
                string responseMessage;
                try
                {
                    responseMessage = GetResponseMessage(requestMessage);
                }
                catch (Exception ex)
                {
                    responseMessage = GetBadPage(ex.Message);
                }

                Console.WriteLine($"Sent response: {responseMessage}");
                var message = Encoding.UTF8.GetBytes(responseMessage);
                stream.Write(message, 0, message.Length);
                stream.Flush();
            }
            finally
            {
                stream.Close();
                client.Close();
            }
        }

        private string GetResponseMessage(string messageData)
        {
            string page = "";
            Regex requestRegex = new Regex("\r\n\r\n");
            string[] requestData = requestRegex.Split(messageData, 2);
            if (requestData.Length != 2)
            {
                return GetBadPage();
            }
            var requestTitle = requestData[0];
            var requestBody = requestData[1];
            var titleMatch = _requestTitleRegex.Match(requestTitle.Split("\r\n")[0]);
            var httpMethod = titleMatch.Groups["httpMethod"].Value;
            var httpPath = titleMatch.Groups["httpPath"].Value;
            
            if (httpPath.Equals("/"))
            {
                return httpMethod switch
                {
                    "GET" => GetMainPage(),
                    _ => GetNotFoundPage(),
                };
            }
            else if (httpPath.Equals("/sort/mergeSort", StringComparison.InvariantCultureIgnoreCase))
            {
                return httpMethod switch
                {
                    "GET" => GetMergeSortPage(),
                    "POST" => GetMergeSortResponsePage(requestBody),
                    _ => GetNotFoundPage(),
                };
            }
            //if (messageData.StartsWith("POST"))
            //{
            //    if (request.Length != 2)
            //    {
            //        page = BadAnswerPage();
            //    }
            //    else
            //    {
            //        String val = request[1].Split('=')[1];

            //        int size;
            //        if (!int.TryParse(val, out size))
            //        {
            //            page = BadAnswerPage();
            //        }
            //        else
            //        {
            //            int[] array = TreeSortLib.QuickSort.InitRandomArray(size);
            //            int[] sortedArrayByTree = TreeSortLib.QuickSort.Sort(array);
            //            page = AnswerPage(array, sortedArrayByTree);
            //        }
            //    }
            //}
            //else
            //{
            //    page = IndexPage();
            //}

            return page;
        }

        private string ReadMessage(NetworkStream stream)
        {
            var buffer = new byte[BufferSize];
            var messageData = new StringBuilder();
            int bytes;
            do
            {
                bytes = stream.Read(buffer, 0, buffer.Length);
                messageData.Append(Encoding.UTF8.GetString(buffer, 0, bytes));
            }
            while (bytes == BufferSize);

            return messageData.ToString();
        }

        public static string SuccessHeaders(int contentLength)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("HTTP/1.1 200 OK").Append("\r\n");
            builder.Append("Date:").Append(DateTime.Now).Append("\r\n");
            builder.Append("Server:lab5-server").Append("\r\n");
            builder.Append("Content-Type:text/html;charset=UTF-8").Append("\r\n");
            builder.Append("Content-Length:").Append(contentLength).Append("\r\n");
            builder.Append("Connection:close").Append("\r\n");
            builder.Append("\r\n");

            return builder.ToString();
        }

        private string GetMainPage()
        {
            StringBuilder bodyBuilder = new StringBuilder();
            bodyBuilder.Append("<a href='/sort/mergeSort'>Merge sort</a>");
            string body = bodyBuilder.ToString();

            return string.Concat(SuccessHeaders(body.Length), body);
        }

        private string GetNotFoundPage()
        {
            StringBuilder bodyBuilder = new StringBuilder();
            bodyBuilder.Append("Page not found");
            bodyBuilder.Append("<br/>");
            bodyBuilder.Append("<a href='/'>Go to main page</a>");
            StringBuilder builder = new StringBuilder();
            builder.Append("HTTP/1.1 404 NotFound").Append("\r\n");
            builder.Append("Date:").Append(DateTime.Now).Append("\r\n");
            builder.Append("Server:lab5-server").Append("\r\n");
            builder.Append("Content-Type:text/html;charset=UTF-8").Append("\r\n");
            builder.Append("Content-Length:").Append(bodyBuilder.Length).Append("\r\n");
            builder.Append("Connection:close").Append("\r\n");
            builder.Append("\r\n");
            builder.Append(bodyBuilder);

            return builder.ToString();
        }

        private static string GetBadPage(string message = "Something went wrong")
        {
            StringBuilder bodyBuilder = new StringBuilder();
            bodyBuilder.Append(message);
            bodyBuilder.Append("<br/>");
            bodyBuilder.Append("<a href='/'>Go to main page</a>");
            string body = bodyBuilder.ToString();

            return string.Concat(SuccessHeaders(body.Length), body);
        }

        private string GetMergeSortPage()
        {
            StringBuilder bodyBuilder = new StringBuilder();
            bodyBuilder.Append("<form method='post'>");
            bodyBuilder.Append("Merge sort. Input array:");
            bodyBuilder.Append("<br/>");
            bodyBuilder.Append("<input type='text' name='array'>");
            bodyBuilder.Append("<br/>");
            bodyBuilder.Append("<input type='submit'>");
            bodyBuilder.Append("</form>");
            string body = bodyBuilder.ToString();
            return string.Concat(SuccessHeaders(body.Length), body);
        }

        private string GetMergeSortResponsePage(string body)
        {
            int[] array;
            var stringArray = body.Split('=')[1].Split("+", StringSplitOptions.RemoveEmptyEntries);

            StringBuilder bodyBuilder = new StringBuilder();
            if (stringArray.Length == 0)
            {
                bodyBuilder.Append("Cannot sort empty array");
                bodyBuilder.Append("<br/>");
            }
            else
            {
                array = stringArray.Select(item => int.Parse(item)).ToArray();
                var sorter = new MergeSortSolver();
                var sortedArray = array.ToArray();
                sorter.Sort(sortedArray);
                bodyBuilder.Append("Array before sorting:");
                bodyBuilder.Append("<br/>");
                bodyBuilder.Append(string.Join(",", array));
                bodyBuilder.Append("<br/>");
                bodyBuilder.Append("Sorted array:");
                bodyBuilder.Append("<br/>");
                bodyBuilder.Append(string.Join(",", sortedArray));
                bodyBuilder.Append("<br/>");
            }

            bodyBuilder.Append("<a href='/sort/mergeSort'>Sort another array</a>");

            return string.Concat(SuccessHeaders(bodyBuilder.Length), bodyBuilder.ToString());
        }

    }
}
